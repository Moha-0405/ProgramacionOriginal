package ejercicio2;

public class Ejercicio2 {

	public static void main(String[] args) 
	{
		int numero;
		
		for(numero=0;numero<=200;numero=numero+2)
		{
			System.out.println(numero);
		}

	}

}
