package ejercicio3;

public class Ejercicio3 
{
	public static void main(String[] args) 
	{
		int numero;
		
		for(numero=0;numero<200;numero++)
		{
			
			System.out.println((numero+1));
		}
	}
}
