package ejercicio9;

public class Ejercicio9 {

	public static void main(String[] args) 
	{
		int suma=0;
		int multiplicacion=1;
		
		
		for(int i=1; i<=10;i++)
		{
			suma=suma+i;
			multiplicacion=multiplicacion*i;
		}
		
		System.out.println("la suma es= "+suma);
		System.out.println("la multiplicacion es= "+multiplicacion);
	}

}
