package ejercicio7;

import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) 
	{
		Scanner teclado= new Scanner(System.in);
		
		System.out.println("Dame el primer numero");
		int numA=teclado.nextInt();
		
		System.out.println("Dame el segundo numero");
		int numZ=teclado.nextInt();
		
		
		if(numZ<numA)
		{
			System.out.println("El primer numero no puede ser mayor al segundo numero.");
		}
		else
		{
			int posicion=(numZ-numA)+1;
			int[] numero=new int[posicion];
			int contador=0;
			int valor = numA;
			
			while(valor<=numZ)
			{
				numero[numA]=numA;
				System.out.println("El numero guardado en la posicion "+(numero[contador]++)+" es "+ (valor++));
				
			}
		}
		
	}

}
