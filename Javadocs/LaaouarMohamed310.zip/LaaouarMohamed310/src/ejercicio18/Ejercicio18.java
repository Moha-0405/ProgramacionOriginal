package ejercicio18;

import java.util.Arrays;

public class Ejercicio18 {

	public static void main(String[] args) 
	{
		final int TOTAL_NUM = 30;
		
		double[] aleatorio = new double [TOTAL_NUM];
		
			for (int posicion = 0; posicion < aleatorio.length; posicion++) {
				aleatorio[posicion] = (Math.random() * 10);
			}
		
		Arrays.sort(aleatorio);

		for (int posicion = 0; posicion < aleatorio.length; posicion++) 
		{
			System.out.println(aleatorio[posicion]);
		}
		
	}

}
