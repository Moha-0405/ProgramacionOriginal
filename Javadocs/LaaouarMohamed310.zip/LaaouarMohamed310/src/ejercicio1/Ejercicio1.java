package ejercicio1;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) 
	{
		Scanner teclado= new Scanner(System.in);
		
		final int POSICION=10;
		double[] numero=new double[POSICION];
		
		for(int contador=0;contador<10;contador++)
		{
			System.out.println("Dame un numero");
			numero[contador]=teclado.nextInt();
			System.out.println("El valor: "+ numero[contador]+" ha sido guardado");
			
		}
		
		
	}

}
