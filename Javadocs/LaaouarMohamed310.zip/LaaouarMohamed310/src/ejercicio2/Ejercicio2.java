package ejercicio2;

import java.util.Scanner;

public class Ejercicio2 
{
	public static void main(String[] args) 
	{
		Scanner teclado= new Scanner(System.in);
		
		final int POSICION=10;
		double[] numero=new double[POSICION];
		double suma=0;
		
		for(int contador=0;contador<10;contador++)
		{
			System.out.println("Dame un numero");
			numero[contador]=teclado.nextInt();
			suma=suma+numero[contador];
			
		}
		System.out.println("El valor total de la suma: "+ suma);
	}
	
}